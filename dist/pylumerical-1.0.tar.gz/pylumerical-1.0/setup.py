from distutils.core import setup
setup(name='pylumerical',
      version='1.0',
      py_modules=['pylumerical'],
      )
